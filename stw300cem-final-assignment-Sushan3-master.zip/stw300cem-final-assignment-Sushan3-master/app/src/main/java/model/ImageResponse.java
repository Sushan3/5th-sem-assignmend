package model;

public class ImageResponse {

    private String filename;

    public String getFileName() {
        return filename;
    }
}
