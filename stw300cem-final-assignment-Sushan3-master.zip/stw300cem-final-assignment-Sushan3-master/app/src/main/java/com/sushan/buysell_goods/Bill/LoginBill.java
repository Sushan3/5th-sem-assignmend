package com.sushan.buysell_goods.Bill;

public class LoginBill {

//    private String username;
//    private String password;
//    boolean isSuccess = false;
//
//    public LoginBill(String username, String password) {
//        this.username = username;
//        this.password = password;
//    }
//
//    public boolean checkUser() {
//
//        Users user = new Users(username, password);
//        API api = Reusable.getInstance().create(API.class);
//        Call<LoginSignupResponse> usercall = api.loginUser(user);
//
//        try
//        {
//            Response<LoginSignupResponse>loginSignupResponseResponse = usercall.execute();
//            if (loginSignupResponseResponse.body().getSuccess()) {
//                isSuccess = true;
//
//            }
//        }
//        catch (IOException e){
//            e.printStackTrace();
//        }
//        return isSuccess;
//
//
//    }
}
