package com.sushan.buysell_goods;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;

public class LoginTest {


//    @Test
//    public  void testLogin()
//    {
//
//        LoginBill loginBill = new LoginBill("bijay", "bijay");
//        boolean result = loginBill.checkUser();
//        assertEquals(true, result);
//    }
}
