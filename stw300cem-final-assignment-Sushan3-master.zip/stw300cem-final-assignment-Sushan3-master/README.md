# stw300cem-final-assignment-Sushan3
stw300cem-final-assignment-Sushan3 created by GitHub Classroom
Buy and Sell Goods
Introduction
Buying and selling is a big bang worldwide project where any user can buy and sell their products online. In this application user can buy goods and sell it. This a very good platform to get engage in buying and selling product through online. Modern technology nowadays, especially smartphone technology, has several advantageous functions, faster computational time, wider screens, and higher capability.
Feature of Project
1.	User Login
2.	Admin Login
3.	Order different Goods
4.	Admin CRUD function

Android project YouTube video link
	Link :- https://youtu.be/Kg4Rviy3JZk
API link
	Link :- https://github.com/Sushan3/Backend-API-Code-repository_Buy-Sell.git


Retrofit and Its Uses.
Retrofit is a REST Client for Android and Java by Square. It makes it relatively easy to retrieve and upload JSON (or other structured data) via a REST based web service. In Retrofit you configure which converter is used for the data serialization. Typically for JSON you use GSon, but you can add custom converters to process XML or other protocols. Retrofit uses the OkHttp library for HTTP requests.
•	Retrofit will save your development time.
•	And also you can keep your code in developer friendly. 
•	Retrofit has given almost all the API's to make server call and to receive response.


